import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: '#060402',
        surface: '#0C0906',
        orange: {
          DEFAULT: '#FF6B00',
          2: '#FF8C00',
          3: '#FFA500',
          4: '#FFB347',
          5: '#FFD580',
        },
        red: '#FF3D00',
        cream: '#FFF8F0',
        muted: {
          DEFAULT: '#7A5C3A',
          2: '#C4956A',
        },
      },
      fontFamily: {
        sans: ['Space Grotesk', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      backgroundImage: {
        'orange-gradient': 'linear-gradient(135deg, #FF3D00, #FF6B00, #FF8C00, #FFB347, #FFD580)',
        'glass-gradient': 'linear-gradient(135deg, rgba(255,107,0,0.12), rgba(255,140,0,0.04))',
      },
      animation: {
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'spin-slow': 'spin 10s linear infinite',
        'orb-float': 'orbFloat 18s ease-in-out infinite',
        'fade-up': 'fadeUp 0.7s ease forwards',
        'typewriter': 'blink 0.8s infinite',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '1', boxShadow: '0 0 10px #FF6B00, 0 0 20px rgba(255,107,0,0.4)' },
          '50%': { opacity: '0.5', boxShadow: '0 0 4px #FF6B00' },
        },
        orbFloat: {
          '0%, 100%': { transform: 'translate(0, 0) scale(1)' },
          '33%': { transform: 'translate(60px, -50px) scale(1.08)' },
          '66%': { transform: 'translate(-50px, 35px) scale(0.92)' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(28px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        blink: {
          '0%, 100%': { borderColor: '#FF6B00' },
          '50%': { borderColor: 'transparent' },
        },
      },
      borderRadius: {
        '4xl': '2rem',
      },
      backdropBlur: {
        '3xl': '64px',
      },
    },
  },
  plugins: [],
}
export default config
