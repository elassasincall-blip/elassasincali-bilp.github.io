'use client'
import { useEffect, useRef } from 'react'

export default function Cursor() {
  const dotRef = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)
  const pos = useRef({ x: 0, y: 0 })
  const ring = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      pos.current = { x: e.clientX, y: e.clientY }
      if (dotRef.current) {
        dotRef.current.style.left = `${e.clientX}px`
        dotRef.current.style.top = `${e.clientY}px`
      }
    }

    const animate = () => {
      ring.current.x += (pos.current.x - ring.current.x) * 0.12
      ring.current.y += (pos.current.y - ring.current.y) * 0.12
      if (ringRef.current) {
        ringRef.current.style.left = `${ring.current.x}px`
        ringRef.current.style.top = `${ring.current.y}px`
      }
      requestAnimationFrame(animate)
    }

    document.addEventListener('mousemove', onMove)
    const raf = requestAnimationFrame(animate)

    const interactables = document.querySelectorAll(
      'button, a, .hover-lift, input, textarea, .bc, .stat, .trophy, .kcard, .chip'
    )
    interactables.forEach((el) => {
      el.addEventListener('mouseenter', () => {
        if (dotRef.current) { dotRef.current.style.width = '16px'; dotRef.current.style.height = '16px' }
        if (ringRef.current) {
          ringRef.current.style.width = '52px'
          ringRef.current.style.height = '52px'
          ringRef.current.style.borderColor = 'rgba(255,107,0,0.8)'
        }
      })
      el.addEventListener('mouseleave', () => {
        if (dotRef.current) { dotRef.current.style.width = '12px'; dotRef.current.style.height = '12px' }
        if (ringRef.current) {
          ringRef.current.style.width = '40px'
          ringRef.current.style.height = '40px'
          ringRef.current.style.borderColor = 'rgba(255,107,0,0.5)'
        }
      })
    })

    return () => {
      document.removeEventListener('mousemove', onMove)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <>
      <div id="cursor-dot" ref={dotRef} />
      <div id="cursor-ring" ref={ringRef} />
    </>
  )
}
