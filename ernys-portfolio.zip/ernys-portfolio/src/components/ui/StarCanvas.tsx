'use client'
import { useEffect, useRef } from 'react'

interface Star {
  x: number; y: number; r: number
  o: number; s: number; c: string
}

const COLORS = [
  'rgba(255,107,0,', 'rgba(255,165,0,',
  'rgba(255,200,80,', 'rgba(200,120,40,', 'rgba(255,80,0,',
]

export default function StarCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let W = (canvas.width = window.innerWidth)
    let H = (canvas.height = window.innerHeight)
    let stars: Star[] = []
    let rafId: number

    const init = () => {
      stars = Array.from({ length: 220 }, () => ({
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 0.8 + 0.1,
        o: Math.random() * 0.5 + 0.1,
        s: Math.random() * 0.0004 + 0.0001,
        c: COLORS[Math.floor(Math.random() * COLORS.length)],
      }))
    }

    const draw = () => {
      ctx.clearRect(0, 0, W, H)
      stars.forEach((s) => {
        s.o += s.s
        if (s.o > 0.65 || s.o < 0.08) s.s = -s.s
        ctx.beginPath()
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2)
        ctx.fillStyle = s.c + s.o + ')'
        ctx.fill()
      })
      rafId = requestAnimationFrame(draw)
    }

    const onResize = () => {
      W = canvas.width = window.innerWidth
      H = canvas.height = window.innerHeight
      init()
    }

    init()
    draw()
    window.addEventListener('resize', onResize)
    return () => {
      cancelAnimationFrame(rafId)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none' }}
    />
  )
}
