'use client'
import { useEffect, useRef, useState } from 'react'
import { skills, achievements } from '@/lib/data'
import { SectionLabel, SectionTitle } from './AboutSection'

const barGradient = {
  orange: 'linear-gradient(90deg, #FF3D00, #FF6B00, #FFA500)',
  amber:  'linear-gradient(90deg, #FF6B00, #FFB347, #FFD580)',
  green:  'linear-gradient(90deg, #10B981, #FF8C00)',
  purple: 'linear-gradient(90deg, #8B5CF6, #FF8C00)',
}

export function SkillsSection() {
  const [animated, setAnimated] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setAnimated(true); obs.disconnect() } },
      { threshold: 0.2 }
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <section id="skills" ref={ref} style={{ padding: '90px 0', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Habilidades técnicas</SectionLabel>
        <SectionTitle>Stack de Aprendizaje</SectionTitle>
        <p style={{ color: '#C4956A', maxWidth: 520, marginTop: '.4rem', fontSize: '.95rem' }}>
          Autodidacta y subiendo de nivel en todo el stack — de frontend a cloud, IA y seguridad.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: 12, marginTop: '3rem' }}>
          {skills.map((sk) => (
            <div
              key={sk.name}
              className="gl hover-lift"
              style={{ padding: 20, borderRadius: 14, transition: 'all 0.2s' }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span>{sk.icon}</span>{sk.name}
                </div>
                <div style={{ fontSize: 12, fontFamily: 'JetBrains Mono', color: '#FFA500', fontWeight: 700, textShadow: '0 0 10px rgba(255,165,0,0.3)' }}>
                  {sk.level}%
                </div>
              </div>
              <div style={{ height: 3, background: 'rgba(255,255,255,0.05)', borderRadius: 2, overflow: 'hidden' }}>
                <div
                  className="skill-fill"
                  style={{
                    width: animated ? `${sk.level}%` : '0%',
                    background: barGradient[sk.variant],
                  }}
                />
              </div>
              <div style={{ fontSize: 11, color: '#7A5C3A', marginTop: 7, fontFamily: 'JetBrains Mono' }}>{sk.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

const badgeStyle = {
  green: { bg: 'rgba(16,185,129,0.1)', color: '#34D399', border: '1px solid rgba(16,185,129,0.25)' },
  orange: { bg: 'rgba(255,107,0,0.1)', color: '#FFA500', border: '1px solid rgba(255,107,0,0.25)' },
  amber: { bg: 'rgba(255,180,0,0.1)', color: '#FFD580', border: '1px solid rgba(255,180,0,0.25)' },
}

export function AchievementsSection() {
  return (
    <section id="trophies" style={{ padding: '90px 0', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Sala de Trofeos</SectionLabel>
        <SectionTitle>Certificaciones y Logros</SectionTitle>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: 12, marginTop: '3rem' }}>
          {achievements.map((a) => (
            <div
              key={a.title}
              className={a.glow ? 'gl3' : 'gl'}
              style={{ padding: '24px 20px', textAlign: 'center', borderRadius: 20, transition: 'all 0.3s', position: 'relative', overflow: 'hidden', cursor: 'default' }}
            >
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 70% 50% at 50% 0%, rgba(255,107,0,0.12), transparent)', pointerEvents: 'none' }} />
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,180,60,0.4), transparent)' }} />
              <div
                style={{
                  position: 'absolute', top: 12, right: 12, fontSize: 10,
                  padding: '3px 9px', borderRadius: 5, fontFamily: 'JetBrains Mono',
                  ...badgeStyle[a.badgeColor],
                }}
              >
                {a.badge}
              </div>
              <span style={{ fontSize: '2.2rem', display: 'block', marginBottom: 12, position: 'relative', zIndex: 1 }}>{a.icon}</span>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 5, position: 'relative', zIndex: 1 }}>{a.title}</div>
              <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono', color: '#FFA500', marginBottom: 8, position: 'relative', zIndex: 1 }}>{a.org}</div>
              <div style={{ fontSize: 12, color: '#7A5C3A', lineHeight: 1.55, position: 'relative', zIndex: 1 }}>{a.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
