import { ideas, owner } from '@/lib/data'
import { SectionLabel, SectionTitle } from './AboutSection'

// ── IDEA LAB ──────────────────────────────────────────────
export function IdeaLabSection() {
  const cols = [
    { key: 'exploring' as const, label: 'Explorando', dotColor: '#FFB347', glow: 'rgba(255,180,0,0.6)', glClass: 'gl' },
    { key: 'building' as const, label: 'Construyendo', dotColor: '#FF6B00', glow: 'rgba(255,107,0,0.7)', glClass: 'gl' },
    { key: 'launched' as const, label: 'Lanzado', dotColor: '#10B981', glow: 'rgba(16,185,129,0.6)', glClass: 'gl2' },
  ]

  return (
    <section id="ideas" style={{ padding: '90px 0', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Pipeline de innovación</SectionLabel>
        <SectionTitle>Laboratorio de Ideas</SectionTitle>
        <p style={{ color: '#C4956A', maxWidth: 520, marginTop: '.4rem', fontSize: '.95rem' }}>
          Las ideas y proyectos futuros en mi pipeline — del concepto a la ejecución.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginTop: '3rem' }}>
          {cols.map((col) => (
            <div
              key={col.key}
              className={col.glClass}
              style={{ padding: 18, borderRadius: 20 }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, paddingBottom: 14, borderBottom: '1px solid rgba(255,107,0,0.12)' }}>
                <div style={{ fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: col.dotColor, display: 'inline-block', boxShadow: `0 0 8px ${col.glow}` }} />
                  {col.label}
                </div>
                <div style={{ fontSize: 11, background: 'rgba(255,107,0,0.08)', border: '1px solid rgba(255,107,0,0.2)', color: '#FFA500', padding: '2px 8px', borderRadius: 5, fontFamily: 'JetBrains Mono' }}>
                  {ideas[col.key].length}
                </div>
              </div>
              {ideas[col.key].map((idea) => (
                <div
                  key={idea.title}
                  style={{
                    background: 'rgba(6,4,2,0.55)', border: `1px solid ${col.key === 'launched' ? 'rgba(16,185,129,0.2)' : col.key === 'building' ? 'rgba(255,107,0,0.2)' : 'rgba(255,107,0,0.12)'}`,
                    borderRadius: 12, padding: 14, marginBottom: 10, transition: 'border-color 0.2s', cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{idea.title}</div>
                  <div style={{ fontSize: 12, color: '#7A5C3A', lineHeight: 1.55, marginBottom: 10 }}>{idea.description}</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {idea.tags.map((t) => (
                      <span key={t} style={{ fontSize: 10, padding: '2px 8px', borderRadius: 4, fontFamily: 'JetBrains Mono', background: 'rgba(255,107,0,0.06)', color: '#C4956A', border: '1px solid rgba(255,107,0,0.12)' }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── CONTACT ──────────────────────────────────────────────
export function ContactSection() {
  const links = [
    { icon: '✉', label: 'Email', value: owner.email, href: `mailto:${owner.email}`, glow: false },
    { icon: '💼', label: 'LinkedIn', value: 'Ernys Napoles Favier', href: owner.linkedin, glow: false },
    { icon: '🐙', label: 'GitHub', value: 'github.com/ernysnf', href: owner.github, glow: false },
    { icon: '🏢', label: 'Empresa', value: 'orvexia.com', href: owner.company, glow: true },
  ]

  return (
    <section id="contact" style={{ padding: '90px 0 80px', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Contacto</SectionLabel>
        <SectionTitle>Construyamos Algo</SectionTitle>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem', marginTop: '3rem' }}>
          {/* INFO */}
          <div>
            <h3 style={{ fontSize: '1.55rem', fontWeight: 700, letterSpacing: '-0.02em', marginBottom: '1rem' }}>
              ¿Listo para colaborar, invertir o contratar?
            </h3>
            <p style={{ color: '#C4956A', lineHeight: 1.85, marginBottom: '2rem', fontSize: '.95rem' }}>
              Abierto a trabajo por contrato, asociaciones y conversaciones con inversores. Si resuelves problemas reales en{' '}
              <strong style={{ color: '#FFA500' }}>transporte o tecnología</strong> — hablemos.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {links.map((l) => (
                <a
                  key={l.label}
                  href={l.href}
                  className={l.glow ? 'gl3' : 'gl'}
                  style={{ display: 'flex', alignItems: 'center', gap: 14, borderRadius: 14, padding: '14px 18px', textDecoration: 'none', color: '#FFF8F0', transition: 'all 0.2s' }}
                >
                  <div style={{ fontSize: 18, width: 24, textAlign: 'center' }}>{l.icon}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, color: '#7A5C3A', fontFamily: 'JetBrains Mono', marginBottom: 2 }}>{l.label}</div>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{l.value}</div>
                  </div>
                  <span style={{ color: '#FFA500', fontSize: 16, textShadow: '0 0 10px rgba(255,165,0,0.4)' }}>→</span>
                </a>
              ))}
            </div>
          </div>

          {/* FORM */}
          <div className="gl" style={{ borderRadius: 20, padding: 28 }}>
            {[
              { label: 'Nombre', type: 'text', placeholder: 'Tu nombre completo' },
              { label: 'Email', type: 'email', placeholder: 'tu@email.com' },
              { label: 'Asunto', type: 'text', placeholder: 'Asociación, contratar, invertir...' },
            ].map((f) => (
              <div key={f.label}>
                <label style={{ display: 'block', fontSize: 11, color: '#7A5C3A', fontFamily: 'JetBrains Mono', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 8 }}>
                  {f.label}
                </label>
                <input
                  type={f.type}
                  placeholder={f.placeholder}
                  style={{
                    width: '100%', background: 'rgba(6,4,2,0.7)', border: '1px solid rgba(255,107,0,0.15)',
                    borderRadius: 10, padding: '12px 16px', color: '#FFF8F0',
                    fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, outline: 'none', marginBottom: 16,
                  }}
                />
              </div>
            ))}
            <label style={{ display: 'block', fontSize: 11, color: '#7A5C3A', fontFamily: 'JetBrains Mono', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 8 }}>
              Mensaje
            </label>
            <textarea
              placeholder="Cuéntame qué estás construyendo..."
              rows={4}
              style={{
                width: '100%', background: 'rgba(6,4,2,0.7)', border: '1px solid rgba(255,107,0,0.15)',
                borderRadius: 10, padding: '12px 16px', color: '#FFF8F0',
                fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, outline: 'none', resize: 'vertical',
              }}
            />
            <button
              style={{
                width: '100%', background: 'linear-gradient(135deg, #FF3D00, #FF6B00, #FF8C00)',
                color: '#fff', border: 'none', padding: 14, borderRadius: 10,
                fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'Space Grotesk, sans-serif',
                marginTop: 16, boxShadow: '0 0 40px rgba(255,107,0,0.25), inset 0 1px 0 rgba(255,255,255,0.15)',
                transition: 'opacity 0.2s',
              }}
            >
              Enviar Mensaje →
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
