import { projects } from '@/lib/data'
import { SectionLabel, SectionTitle } from './AboutSection'

export default function ProjectsSection() {
  const route = projects.find((p) => p.id === 'route-manager-pro')!
  const orvexia = projects.find((p) => p.id === 'orvexia')!
  const aiLab = projects.find((p) => p.id === 'ai-lab')!
  const secLab = projects.find((p) => p.id === 'sec-lab')!

  return (
    <section id="projects" style={{ padding: '90px 0', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Lo que construyo</SectionLabel>
        <SectionTitle>Proyectos y Productos</SectionTitle>

        {/* BENTO GRID */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gridAutoRows: 'minmax(60px, auto)', gap: 14, marginTop: '3rem' }}>

          {/* ROUTE MANAGER PRO */}
          <BentoCard style={{ gridColumn: 'span 7', gridRow: 'span 3' }} glLevel="gl">
            <BentoBadge color="green">★ PRODUCTO PRINCIPAL</BentoBadge>
            <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: 10, letterSpacing: '-0.01em' }}>Route Manager Pro</h3>
            <p style={{ fontSize: 13, color: '#C4956A', lineHeight: 1.75, flex: 1 }}>{route.description}</p>
            <AppMockup />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, margin: '12px 0' }}>
              {route.tags.map((t) => <Tag key={t}>{t}</Tag>)}
            </div>
            <BentoFooter status="ACTIVO" statusColor="#10B981" />
          </BentoCard>

          {/* ORVEXIA */}
          <BentoCard style={{ gridColumn: 'span 5', gridRow: 'span 3' }} glLevel="gl3">
            <BentoBadge color="orange">EMPRESA FUNDADA</BentoBadge>
            <div
              style={{
                fontSize: '2.8rem', fontWeight: 700, fontFamily: 'JetBrains Mono, monospace',
                background: 'linear-gradient(135deg, #FF3D00, #FF6B00, #FF8C00, #FFB347, #FFD580)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
                letterSpacing: '-0.03em', lineHeight: 1,
                filter: 'drop-shadow(0 0 24px rgba(255,107,0,0.5))',
              }}
            >
              ORVEXIA
            </div>
            <div style={{ fontSize: 11, color: '#7A5C3A', fontFamily: 'JetBrains Mono', letterSpacing: '.15em', marginBottom: 14 }}>
              TECHNOLOGY COMPANY
            </div>
            <p style={{ fontSize: 13, color: '#C4956A', lineHeight: 1.75, flex: 1 }}>{orvexia.description}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
              {orvexia.roadmap?.map((r, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12 }}>
                  <div style={{
                    width: 6, height: 6, borderRadius: '50%', flexShrink: 0,
                    background: r.done ? '#10B981' : r.active ? '#FF6B00' : '#7A5C3A',
                    boxShadow: r.done ? '0 0 6px rgba(16,185,129,0.5)' : r.active ? '0 0 6px rgba(255,107,0,0.5)' : 'none',
                  }} />
                  <span style={{ color: r.done ? '#34D399' : r.active ? '#FFA500' : '#7A5C3A', fontFamily: 'JetBrains Mono', fontSize: 11, minWidth: 36 }}>
                    {r.label}
                  </span>
                  <span style={{ color: r.done || r.active ? '#C4956A' : '#7A5C3A', fontSize: 12 }}>{r.text}</span>
                </div>
              ))}
            </div>
            <BentoFooter status="EMPRESA ACTIVA" statusColor="#FF6B00" />
          </BentoCard>

          {/* AI LAB */}
          <BentoCard style={{ gridColumn: 'span 4', gridRow: 'span 2' }} glLevel="gl">
            <BentoBadge color="amber">AI/ML</BentoBadge>
            <div className="text-orange-soft" style={{ fontSize: '2rem', fontWeight: 700, fontFamily: 'JetBrains Mono' }}>AI_LAB</div>
            <p style={{ fontSize: 13, color: '#C4956A', lineHeight: 1.75, marginTop: 8, flex: 1 }}>{aiLab.description}</p>
            <BentoFooter status="EN PROGRESO" statusColor="#FF8C00" />
          </BentoCard>

          {/* SEC LAB */}
          <BentoCard style={{ gridColumn: 'span 4', gridRow: 'span 2' }} glLevel="gl">
            <BentoBadge color="orange">SECURITY</BentoBadge>
            <div className="text-orange-soft" style={{ fontSize: '2rem', fontWeight: 700, fontFamily: 'JetBrains Mono' }}>SEC_LAB</div>
            <p style={{ fontSize: 13, color: '#C4956A', lineHeight: 1.75, marginTop: 8, flex: 1 }}>{secLab.description}</p>
            <BentoFooter status="ESTUDIANDO" statusColor="#FF6B00" />
          </BentoCard>

          {/* STATUS */}
          <BentoCard style={{ gridColumn: 'span 4', gridRow: 'span 2' }} glLevel="gl2">
            <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono', color: '#7A5C3A', textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 14 }}>
              Estado actual
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11, flex: 1 }}>
              {[
                { dot: '#FF6B00', text: 'Abierto a colaboraciones' },
                { dot: '#FFA500', text: 'Construyendo ORVEXIA' },
                { dot: '#8B5CF6', text: 'Full Stack + AI + Sec' },
              ].map((s) => (
                <div key={s.text} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: s.dot, boxShadow: `0 0 8px ${s.dot}60` }} />
                  <span style={{ fontSize: 13, color: '#C4956A' }}>{s.text}</span>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono', color: '#7A5C3A', paddingTop: 14 }}>Houston, TX · 2024</div>
          </BentoCard>

        </div>
      </div>
    </section>
  )
}

// ── Sub-components ──

function BentoCard({ children, style, glLevel }: { children: React.ReactNode; style?: React.CSSProperties; glLevel: 'gl' | 'gl2' | 'gl3' }) {
  return (
    <div
      className={`${glLevel} hover-lift`}
      style={{
        borderRadius: 20, overflow: 'hidden', cursor: 'pointer', position: 'relative',
        ...style,
      }}
    >
      <div style={{ padding: 26, height: '100%', display: 'flex', flexDirection: 'column', minHeight: 200 }}>
        {children}
      </div>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,180,60,0.3), transparent)', pointerEvents: 'none' }} />
    </div>
  )
}

function BentoBadge({ children, color }: { children: React.ReactNode; color: 'green' | 'orange' | 'amber' }) {
  const styles = {
    green: { bg: 'rgba(16,185,129,0.1)', col: '#34D399', border: '1px solid rgba(16,185,129,0.25)' },
    orange: { bg: 'rgba(255,107,0,0.12)', col: '#FFA500', border: '1px solid rgba(255,107,0,0.3)' },
    amber: { bg: 'rgba(255,180,0,0.1)', col: '#FFD580', border: '1px solid rgba(255,180,0,0.25)' },
  }
  const s = styles[color]
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11,
      fontFamily: 'JetBrains Mono', padding: '4px 12px', borderRadius: 6,
      marginBottom: 14, width: 'fit-content',
      background: s.bg, color: s.col, border: s.border,
    }}>
      {children}
    </div>
  )
}

function BentoFooter({ status, statusColor }: { status: string; statusColor: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: statusColor, boxShadow: `0 0 8px ${statusColor}80` }} />
        <span style={{ color: statusColor, fontFamily: 'JetBrains Mono', fontSize: 12 }}>{status}</span>
      </div>
      <div style={{
        width: 32, height: 32, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 16, background: 'rgba(255,107,0,0.1)', border: '1px solid rgba(255,107,0,0.25)', color: '#FFA500',
        transition: 'all 0.2s',
      }}>
        →
      </div>
    </div>
  )
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span style={{
      fontSize: 11, padding: '3px 10px', borderRadius: 5,
      background: 'rgba(255,107,0,0.07)', color: '#C4956A',
      border: '1px solid rgba(255,107,0,0.15)', fontFamily: 'JetBrains Mono',
    }}>
      {children}
    </span>
  )
}

function AppMockup() {
  return (
    <div style={{ background: 'rgba(3,2,1,0.85)', borderRadius: 12, border: '1px solid rgba(255,107,0,0.15)', overflow: 'hidden', marginTop: 14, boxShadow: '0 16px 48px rgba(0,0,0,0.6)' }}>
      <div style={{ background: 'rgba(255,107,0,0.04)', padding: '9px 12px', display: 'flex', alignItems: 'center', gap: 5, borderBottom: '1px solid rgba(255,107,0,0.1)' }}>
        {['#FF5F57','#FFBD2E','#28CA41'].map((c) => <div key={c} style={{ width: 7, height: 7, borderRadius: '50%', background: c }} />)}
        <div style={{ flex: 1, background: 'rgba(255,255,255,0.03)', borderRadius: 4, padding: '4px 10px', fontSize: 10, fontFamily: 'JetBrains Mono', color: '#7A5C3A', marginLeft: 8 }}>
          routemanagerpro.app
        </div>
      </div>
      <div style={{ padding: 14 }}>
        {[null, '70%', '50%'].map((w, i) => (
          <div key={i} style={{ height: 7, background: 'rgba(255,107,0,0.12)', borderRadius: 4, marginBottom: 7, width: w || '100%' }} />
        ))}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 10 }}>
          <div style={{ background: 'rgba(255,107,0,0.08)', border: '1px solid rgba(255,107,0,0.15)', borderRadius: 7, height: 28 }} />
          <div style={{ background: 'rgba(255,107,0,0.08)', border: '1px solid rgba(255,107,0,0.15)', borderRadius: 7, height: 28 }} />
          <div style={{ background: 'rgba(255,107,0,0.04)', border: '1px solid rgba(255,107,0,0.1)', borderRadius: 7, height: 28 }} />
          <div style={{ background: 'rgba(255,107,0,0.04)', border: '1px solid rgba(255,107,0,0.1)', borderRadius: 7, height: 28 }} />
        </div>
      </div>
    </div>
  )
}
