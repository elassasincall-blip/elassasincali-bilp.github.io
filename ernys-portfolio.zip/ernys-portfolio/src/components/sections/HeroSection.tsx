'use client'
import { useEffect, useRef, useState } from 'react'
import { owner, stats, badges, typewriterWords } from '@/lib/data'

function useCounter(target: number, suffix = '', delay = 600) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    const timer = setTimeout(() => {
      let current = 0
      const step = Math.ceil(target / 50)
      const iv = setInterval(() => {
        current = Math.min(current + step, target)
        setValue(current)
        if (current >= target) clearInterval(iv)
      }, 22)
      return () => clearInterval(iv)
    }, delay)
    return () => clearTimeout(timer)
  }, [target, delay])
  return value + suffix
}

function Typewriter({ words }: { words: string[] }) {
  const [display, setDisplay] = useState('')
  const [wordIdx, setWordIdx] = useState(0)
  const [charIdx, setCharIdx] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const word = words[wordIdx]
    if (!deleting) {
      const t = setTimeout(() => {
        setDisplay(word.slice(0, charIdx + 1))
        setCharIdx((c) => c + 1)
        if (charIdx + 1 === word.length) {
          setTimeout(() => setDeleting(true), 1900)
        }
      }, 85)
      return () => clearTimeout(t)
    } else {
      const t = setTimeout(() => {
        setDisplay(word.slice(0, charIdx - 1))
        setCharIdx((c) => c - 1)
        if (charIdx - 1 === 0) {
          setDeleting(false)
          setWordIdx((i) => (i + 1) % words.length)
        }
      }, 55)
      return () => clearTimeout(t)
    }
  }, [display, deleting, charIdx, wordIdx, words])

  return (
    <span
      className="tw-caret"
      style={{
        background: 'linear-gradient(135deg, #FF8C00, #FFB347)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        backgroundClip: 'text',
      }}
    >
      {display || '\u00a0'}
    </span>
  )
}

const dotColors: Record<string, string> = {
  '#FF6B00': '#FF6B00',
  '#FFA500': '#FFA500',
  '#10B981': '#10B981',
  '#FFD580': '#FFD580',
}

export default function HeroSection() {
  return (
    <section
      id="hero"
      style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', paddingTop: 110, paddingBottom: 80, position: 'relative', zIndex: 1 }}
    >
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)', width: '100%' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '3rem', alignItems: 'center' }}>
          {/* LEFT */}
          <div>
            {/* Pill */}
            <div
              className="animate-fade-up"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                background: 'rgba(255,107,0,0.1)', backdropFilter: 'blur(16px)',
                border: '1px solid rgba(255,107,0,0.3)', color: '#FFB347',
                fontSize: 12, fontFamily: 'JetBrains Mono, monospace',
                padding: '7px 18px', borderRadius: 999, marginBottom: 28,
                boxShadow: '0 0 30px rgba(255,107,0,0.1), inset 0 1px 0 rgba(255,200,80,0.1)',
              }}
            >
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#FF6B00', display: 'inline-block', boxShadow: '0 0 8px #FF6B00' }} />
              &nbsp; Disponible · {owner.location}
            </div>

            {/* H1 */}
            <h1
              className="animate-fade-up-1"
              style={{ fontSize: 'clamp(3rem, 7vw, 5.2rem)', fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.03em', marginBottom: '1.4rem' }}
            >
              Construyendo<br />
              <span className="text-orange-gradient">Tecnología</span> desde<br />
              la <Typewriter words={typewriterWords} />
            </h1>

            {/* Sub */}
            <p
              className="animate-fade-up-2"
              style={{ fontSize: '1.05rem', color: '#C4956A', maxWidth: 550, lineHeight: 1.85, marginBottom: '2.5rem' }}
            >
              De chofer{' '}
              <strong style={{ color: '#FFA500', textShadow: '0 0 12px rgba(255,165,0,0.3)' }}>CDL Clase A</strong>{' '}
              a creador de tecnología y empresario. Fundador de{' '}
              <strong style={{ color: '#FFA500' }}>ORVEXIA</strong>. Creador de{' '}
              <strong style={{ color: '#FFA500' }}>Route Manager Pro</strong>.
            </p>

            {/* Buttons */}
            <div className="animate-fade-up-3" style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginBottom: '3.5rem' }}>
              <button
                onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
                style={{
                  background: 'linear-gradient(135deg, #FF3D00, #FF6B00, #FF8C00)',
                  color: '#fff', border: 'none', padding: '14px 28px', borderRadius: 12,
                  fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'Space Grotesk, sans-serif',
                  boxShadow: '0 0 40px rgba(255,107,0,0.35), inset 0 1px 0 rgba(255,255,255,0.2)',
                  transition: 'all 0.2s',
                }}
              >
                Ver Proyectos →
              </button>
              {['Mi Historia', '⬇ Descargar CV', 'Contacto'].map((label) => (
                <button
                  key={label}
                  onClick={() => {
                    if (label === 'Mi Historia') document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })
                    if (label === 'Contacto') document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })
                  }}
                  style={{
                    background: 'rgba(255,107,0,0.06)', color: '#FFF8F0',
                    border: '1px solid rgba(255,107,0,0.2)', padding: '14px 28px', borderRadius: 12,
                    fontSize: 15, fontWeight: 500, cursor: 'pointer', fontFamily: 'Space Grotesk, sans-serif',
                    backdropFilter: 'blur(12px)', transition: 'all 0.2s',
                  }}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Stats */}
            <div
              className="animate-fade-up-4"
              style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}
            >
              {stats.map((s) => (
                <StatCard key={s.label} target={s.value} suffix={s.suffix} label={s.label} />
              ))}
            </div>
          </div>

          {/* AVATAR CARD */}
          <div
            className="gl3"
            style={{ width: 270, flexShrink: 0, padding: '28px 22px', borderRadius: 26, textAlign: 'center', position: 'relative', overflow: 'hidden' }}
          >
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 90% 70% at 50% 0%, rgba(255,107,0,0.18), transparent 65%)', pointerEvents: 'none' }} />
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,200,80,0.5), transparent)' }} />

            {/* Ring */}
            <div style={{ width: 148, height: 148, margin: '0 auto 20px', borderRadius: '50%', background: 'linear-gradient(135deg, #FF3D00, #FF6B00, #FFA500, #FFD580)', padding: 3, position: 'relative' }}>
              <div style={{ position: 'absolute', inset: -8, borderRadius: '50%', border: '1px dashed rgba(255,107,0,0.4)' }} className="animate-spin-slow" />
              <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: '#060402', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span className="text-orange-gradient" style={{ fontSize: '2.2rem', fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' }}>
                  {owner.initials}
                </span>
              </div>
            </div>

            <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 4 }}>{owner.name}</div>
            <div style={{ fontSize: 12, color: '#FFA500', fontFamily: 'JetBrains Mono, monospace', marginBottom: 18, textShadow: '0 0 10px rgba(255,165,0,0.3)' }}>
              {owner.role}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {badges.map((b) => (
                <div
                  key={b.label}
                  className="gl"
                  style={{ padding: '8px 14px', borderRadius: 9, fontSize: 12, display: 'flex', alignItems: 'center', gap: 8, border: '1px solid rgba(255,107,0,0.18)' }}
                >
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: b.color, boxShadow: `0 0 8px ${b.color}`, flexShrink: 0 }} />
                  <span style={{ color: '#C4956A' }}>{b.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, marginTop: 48, color: '#7A5C3A', fontSize: 11, fontFamily: 'JetBrains Mono, monospace', letterSpacing: '.1em' }}>
          <div style={{ width: 1, height: 40, background: 'linear-gradient(#FF6B00, transparent)', animation: 'scrollAnim 2s ease-in-out infinite' }} />
          <span>SCROLL</span>
        </div>
      </div>
      <style>{`
        @keyframes scrollAnim {
          0% { transform: scaleY(0); transform-origin: top; }
          50% { transform: scaleY(1); transform-origin: top; }
          51% { transform: scaleY(1); transform-origin: bottom; }
          100% { transform: scaleY(0); transform-origin: bottom; }
        }
      `}</style>
    </section>
  )
}

function StatCard({ target, suffix, label }: { target: number; suffix: string; label: string }) {
  const val = useCounter(target, suffix)
  return (
    <div
      className="gl hover-lift"
      style={{ padding: '16px 12px', textAlign: 'center', borderRadius: 14, transition: 'all 0.25s' }}
    >
      <div
        className="text-orange-soft"
        style={{ fontSize: '1.8rem', fontWeight: 700, fontFamily: 'JetBrains Mono, monospace' }}
      >
        {val}
      </div>
      <div style={{ fontSize: 10, color: '#7A5C3A', textTransform: 'uppercase', letterSpacing: '.08em', marginTop: 5 }}>
        {label}
      </div>
    </div>
  )
}
