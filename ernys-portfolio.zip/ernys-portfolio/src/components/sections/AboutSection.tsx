import { owner, timeline, techStack } from '@/lib/data'

const dotColor = { orange: '#FF6B00', amber: '#FFA500', green: '#10B981' }
const dotGlow = {
  orange: 'rgba(255,107,0,0.7)',
  amber: 'rgba(255,165,0,0.7)',
  green: 'rgba(16,185,129,0.6)',
}

export default function AboutSection() {
  return (
    <section id="about" style={{ padding: '90px 0', position: 'relative', zIndex: 1 }}>
      <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)' }}>
        <SectionLabel>Historia</SectionLabel>
        <SectionTitle>El Camino que me Formó</SectionTitle>

        <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: '4rem', marginTop: '3rem' }}>
          {/* TEXT */}
          <div>
            {owner.bio.map((p, i) => (
              <p key={i} style={{ color: '#C4956A', lineHeight: 1.9, fontSize: '.98rem', marginBottom: '1rem' }}
                dangerouslySetInnerHTML={{ __html: p.replace(/(Ernys Napoles Favier|Route Manager Pro|ORVEXIA|existe|ciberseguridad|IA|computación en la nube|desarrollo full-stack)/g, '<strong style="color:#FFA500;font-weight:600">$1</strong>') }}
              />
            ))}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginTop: '1.5rem' }}>
              {techStack.map((t) => (
                <span
                  key={t}
                  className="chip"
                  style={{
                    fontSize: 12, fontFamily: 'JetBrains Mono, monospace',
                    padding: '5px 13px', borderRadius: 7,
                    background: 'rgba(255,107,0,0.06)', color: '#C4956A',
                    border: '1px solid rgba(255,107,0,0.15)',
                    transition: 'all 0.2s', cursor: 'default',
                  }}
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* TIMELINE */}
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {timeline.map((item, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '16px 1fr', gap: 16, paddingBottom: i < timeline.length - 1 ? 26 : 0 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div style={{
                    width: 12, height: 12, borderRadius: '50%',
                    background: dotColor[item.color],
                    border: '2px solid #060402',
                    boxShadow: `0 0 10px ${dotGlow[item.color]}, 0 0 20px ${dotGlow[item.color]}`,
                    flexShrink: 0, marginTop: 4,
                  }} />
                  {i < timeline.length - 1 && (
                    <div style={{ flex: 1, width: 1, background: 'linear-gradient(rgba(255,107,0,0.25), transparent)', marginTop: 6 }} />
                  )}
                </div>
                <div>
                  <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: '#FFA500', marginBottom: 4 }}>{item.year}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{item.title}</div>
                  <div style={{ fontSize: 13, color: '#7A5C3A', lineHeight: 1.6 }}>{item.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: '#7A5C3A', textTransform: 'uppercase', letterSpacing: '.12em', display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
      <div style={{ width: 20, height: 1, background: 'linear-gradient(90deg, #FF6B00, #FFA500)' }} />
      {children}
    </div>
  )
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 style={{ fontSize: 'clamp(1.8rem, 3.5vw, 2.7rem)', fontWeight: 700, letterSpacing: '-0.025em', marginBottom: '.5rem' }}>
      {children}
    </h2>
  )
}
