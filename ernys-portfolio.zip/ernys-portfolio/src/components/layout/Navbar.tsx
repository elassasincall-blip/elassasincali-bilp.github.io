'use client'
import { useState } from 'react'

const links = [
  { label: 'Sobre mí', id: 'about' },
  { label: 'Proyectos', id: 'projects' },
  { label: 'Habilidades', id: 'skills' },
  { label: 'Ideas', id: 'ideas' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setOpen(false)
  }

  return (
    <nav
      style={{
        position: 'fixed', top: 16, left: '50%', transform: 'translateX(-50%)',
        zIndex: 100, display: 'flex', alignItems: 'center', gap: 2,
        background: 'rgba(6,4,2,0.6)',
        backdropFilter: 'blur(32px) saturate(2)',
        border: '1px solid rgba(255,107,0,0.25)',
        borderRadius: 999, padding: '5px 6px',
        boxShadow: '0 0 40px rgba(255,107,0,0.08), inset 0 1px 0 rgba(255,160,0,0.1)',
      }}
    >
      <div
        style={{
          width: 7, height: 7, borderRadius: '50%', background: '#FF6B00',
          boxShadow: '0 0 10px #FF6B00, 0 0 20px rgba(255,107,0,0.4)',
          margin: '0 8px 0 4px', animation: 'pulseGlow 2s ease-in-out infinite',
        }}
      />
      {links.map((l) => (
        <button
          key={l.id}
          onClick={() => scrollTo(l.id)}
          style={{
            color: '#C4956A', fontSize: 13, padding: '7px 16px',
            borderRadius: 999, cursor: 'pointer', border: 'none',
            background: 'none', fontFamily: 'Space Grotesk, sans-serif',
            transition: 'all 0.2s',
          }}
          onMouseEnter={(e) => {
            ;(e.target as HTMLElement).style.color = '#FFF8F0'
            ;(e.target as HTMLElement).style.background = 'rgba(255,107,0,0.12)'
          }}
          onMouseLeave={(e) => {
            ;(e.target as HTMLElement).style.color = '#C4956A'
            ;(e.target as HTMLElement).style.background = 'none'
          }}
        >
          {l.label}
        </button>
      ))}
      <button
        onClick={() => scrollTo('contact')}
        style={{
          background: 'linear-gradient(135deg, #FF3D00, #FF6B00, #FF8C00)',
          color: '#fff', fontWeight: 600, fontSize: 13,
          padding: '7px 16px', borderRadius: 999, border: 'none',
          cursor: 'pointer', fontFamily: 'Space Grotesk, sans-serif',
          boxShadow: '0 0 24px rgba(255,107,0,0.35), inset 0 1px 0 rgba(255,255,255,0.15)',
          transition: 'opacity 0.2s',
        }}
        onMouseEnter={(e) => ((e.target as HTMLElement).style.opacity = '0.88')}
        onMouseLeave={(e) => ((e.target as HTMLElement).style.opacity = '1')}
      >
        Contacto →
      </button>
    </nav>
  )
}
