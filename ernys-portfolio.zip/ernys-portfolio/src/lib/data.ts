// ============================================================
// ERNYS NAPOLES FAVIER — PORTFOLIO DATA
// Edit this file to update all content across the site
// ============================================================

export const owner = {
  name: 'Ernys Napoles Favier',
  firstName: 'Ernys',
  initials: 'ENF',
  role: 'Founder @ ORVEXIA',
  location: 'Houston, TX',
  email: 'ernys@orvexia.com',
  linkedin: 'https://linkedin.com/in/ernysnapoles',
  github: 'https://github.com/ernysnf',
  company: 'https://orvexia.com',
  available: true,
  headline: 'Construyendo Tecnología desde la Experiencia',
  subheadline:
    'De chofer CDL Clase A a creador de tecnología y empresario. Fundador de ORVEXIA. Creador de Route Manager Pro.',
  bio: [
    'Soy Ernys Napoles Favier — chofer CDL Clase A que decidió construir tecnología en lugar de solo usarla. Mi camino no empezó en una sala de clases; empezó detrás del volante, gestionando problemas reales de logística con papel y lápiz cuando debían existir mejores herramientas.',
    'Esa brecha entre lo que existe y lo que debería existir se convirtió en mi misión. Empecé a programar para construir mis propias soluciones — comenzando con Route Manager Pro, una herramienta nacida de la frustración real del conductor.',
    'Fundé ORVEXIA como mi empresa tecnológica — una startup bajo la cual estoy construyendo un ecosistema completo de herramientas de transporte y logística. Esto no es un hobby. Es un negocio real.',
    'Estudio ciberseguridad, IA, computación en la nube y desarrollo full-stack en paralelo — porque los mejores constructores entienden todo el stack.',
  ],
}

export const stats = [
  { value: 8, label: 'Proyectos', suffix: '' },
  { value: 3, label: 'Apps', suffix: '' },
  { value: 12, label: 'Certs', suffix: '+' },
  { value: 20, label: 'Ideas', suffix: '+' },
  { value: 10, label: 'Techs', suffix: '+' },
]

export const badges = [
  { label: 'CDL Clase A Driver', color: '#FF6B00' },
  { label: 'Self-Taught Developer', color: '#FFA500' },
  { label: 'AI Enthusiast', color: '#10B981' },
  { label: 'Entrepreneur', color: '#FFD580' },
]

export const typewriterWords = [
  'Real.',
  'del Camión.',
  'Autodidacta.',
  'Emprendedora.',
  'del Fundador.',
  'que Importa.',
]

export const techStack = [
  'Next.js', 'TypeScript', 'React', 'Node.js',
  'Python', 'Supabase', 'AI/ML', 'Cybersecurity',
  'Tailwind CSS', 'PostgreSQL',
]

export const timeline = [
  {
    year: '2015 – 2020',
    title: 'CDL Clase A — Chofer Comercial',
    description: 'Años de conducción construyeron entendimiento profundo de logística, rutas y las ineficiencias que enfrentan los conductores cada día.',
    color: 'orange' as const,
  },
  {
    year: '2021',
    title: 'Comenzó a Aprender Programación',
    description: 'Camino autodidacta — HTML, CSS, JavaScript. Sin carrera universitaria, solo un problema real que resolver.',
    color: 'orange' as const,
  },
  {
    year: '2022',
    title: 'Route Manager Pro v1',
    description: 'Primer producto real. Construido para conductores, por un conductor. Resolvió problemas de flujo de trabajo reales.',
    color: 'amber' as const,
  },
  {
    year: '2023',
    title: 'Fundó ORVEXIA',
    description: 'Lanzó la empresa. Estableció identidad de marca, modelo de negocio y hoja de ruta del ecosistema.',
    color: 'amber' as const,
  },
  {
    year: '2024 – Presente',
    title: 'Full Stack + AI + Ciberseguridad',
    description: 'Expandiendo hacia IA, certificaciones de ciberseguridad, infraestructura cloud y escalando ORVEXIA.',
    color: 'green' as const,
  },
]

export const projects = [
  {
    id: 'route-manager-pro',
    title: 'Route Manager Pro',
    description:
      'App profesional de gestión de rutas construida desde experiencia real del conductor. Organiza direcciones, rutas diarias, notas — elimina el papel del workflow del chofer.',
    longDescription:
      'Una herramienta de workflow construida por alguien que pasó años detrás del volante. Route Manager Pro organiza direcciones, gestiona rutas diarias, registra notas con soporte de fotos, y elimina la ineficiencia en papel que le cuesta horas a los conductores cada semana.',
    badge: '★ PRODUCTO PRINCIPAL',
    badgeColor: 'green' as const,
    tags: ['React Native', 'iOS/Android', 'Logística', 'v2.0 LIVE'],
    status: 'ACTIVO',
    statusColor: '#10B981',
    version: 'v2.0',
    platform: 'iOS+Android',
    founded: '2022',
    url: 'routemanagerpro.app',
    featured: true,
    size: 'large' as const,
    roadmap: [
      { label: '✓ LIVE', text: 'Route Manager Pro v2', done: true },
      { label: 'DEV', text: 'AI Route Optimizer', active: true },
      { label: 'Q3', text: 'Team Sharing & Sync', done: false },
      { label: '2025', text: 'Fleet Dashboard', done: false },
    ],
  },
  {
    id: 'orvexia',
    title: 'ORVEXIA',
    description:
      'Empresa tecnológica construyendo el ecosistema de software moderno para la industria del transporte y la logística.',
    badge: 'EMPRESA FUNDADA',
    badgeColor: 'orange' as const,
    tags: ['Startup', 'SaaS', 'Transportation Tech'],
    status: 'EMPRESA ACTIVA',
    statusColor: '#FF6B00',
    featured: true,
    size: 'large' as const,
    roadmap: [
      { label: '✓', text: 'Route Manager Pro v2', done: true },
      { label: 'DEV', text: 'AI Dispatch Assistant', active: true },
      { label: 'Q3', text: 'Fleet Management Suite', done: false },
      { label: '2025', text: 'Driver Marketplace', done: false },
    ],
  },
  {
    id: 'ai-lab',
    title: 'AI_LAB',
    description: 'Experimentos de IA — NLP para rutas, automatización de logística con machine learning.',
    badge: 'AI/ML',
    badgeColor: 'amber' as const,
    tags: ['Python', 'NLP', 'ML'],
    status: 'EN PROGRESO',
    statusColor: '#FF8C00',
    size: 'small' as const,
  },
  {
    id: 'sec-lab',
    title: 'SEC_LAB',
    description: 'Laboratorios de ciberseguridad, redes y preparación para CompTIA Security+.',
    badge: 'SECURITY',
    badgeColor: 'orange' as const,
    tags: ['CompTIA', 'Networking', 'Ethical Hacking'],
    status: 'ESTUDIANDO',
    statusColor: '#FF6B00',
    size: 'small' as const,
  },
]

export const skills = [
  { name: 'React / Next.js', icon: '⚛', level: 75, label: 'Intermedio → Avanzado', variant: 'orange' as const },
  { name: 'JavaScript / TS', icon: '🟨', level: 70, label: 'Intermedio', variant: 'orange' as const },
  { name: 'Python', icon: '🐍', level: 55, label: 'Principiante → Intermedio', variant: 'green' as const },
  { name: 'Ciberseguridad', icon: '🛡', level: 50, label: 'CompTIA A+ · estudiando', variant: 'purple' as const },
  { name: 'AI / Prompt Eng.', icon: '🤖', level: 65, label: 'Intermedio · uso activo', variant: 'amber' as const },
  { name: 'Cloud / Supabase', icon: '☁', level: 60, label: 'Intermedio · AWS learning', variant: 'orange' as const },
  { name: 'UI/UX Design', icon: '🎨', level: 72, label: 'Fuerte intuición visual', variant: 'purple' as const },
  { name: 'Logística / Ops', icon: '🚛', level: 95, label: 'Experto · 10+ años', variant: 'green' as const },
]

export const achievements = [
  {
    icon: '🚛',
    title: 'Licencia CDL Clase A',
    org: 'Federal Motor Carrier Safety',
    description: 'La credencial que inició el viaje real que llevó a construir tecnología.',
    badge: 'CDL',
    badgeColor: 'green' as const,
  },
  {
    icon: '🛡',
    title: 'CompTIA A+',
    org: 'CompTIA',
    description: 'Base técnica para especialización en ciberseguridad.',
    badge: 'En progreso',
    badgeColor: 'orange' as const,
  },
  {
    icon: '⚡',
    title: 'Google IT Support',
    org: 'Google / Coursera',
    description: 'Redes, sistemas operativos y fundamentos de seguridad.',
    badge: 'Obtenido',
    badgeColor: 'amber' as const,
  },
  {
    icon: '📱',
    title: 'Route Manager Pro',
    org: 'ORVEXIA',
    description: 'Producto real desde cero — sin equipo, sin funding.',
    badge: 'Construido',
    badgeColor: 'green' as const,
    glow: true,
  },
  {
    icon: '🏢',
    title: 'ORVEXIA Company',
    org: 'Fundador',
    description: 'Empresa tecnológica real — marca, productos, visión.',
    badge: 'Fundado',
    badgeColor: 'orange' as const,
    glow: true,
  },
  {
    icon: '💻',
    title: 'Full Stack Dev',
    org: 'Aprendizaje propio',
    description: 'De cero a apps web y móviles completas sin título.',
    badge: 'Autodidacta',
    badgeColor: 'orange' as const,
  },
]

export const ideas = {
  exploring: [
    {
      title: 'AI Dispatch Assistant',
      description: 'IA que parsea emails de despacho y llena Route Manager Pro automáticamente.',
      tags: ['AI', 'NLP', 'Auto'],
    },
    {
      title: 'Driver Fatigue Monitor',
      description: 'Detecta patrones de fatiga usando clasificación ML en sensores móviles.',
      tags: ['Seguridad', 'Mobile', 'IoT'],
    },
    {
      title: 'Freight Rate Analyzer',
      description: 'Datos de mercado en tiempo real para optimizar cargas por ubicación.',
      tags: ['Data', 'API', 'Finance'],
    },
  ],
  building: [
    {
      title: 'Route Manager Pro v3',
      description: 'Optimización con IA, team sharing y cloud sync. Rediseño total.',
      tags: ['Producto', 'AI', 'v3'],
    },
    {
      title: 'Sitio Oficial ORVEXIA',
      description: 'Web corporativo con deck de inversores y media kit. Next.js.',
      tags: ['Brand', 'Next.js', 'Marketing'],
    },
  ],
  launched: [
    {
      title: 'Route Manager Pro v2',
      description: 'Gestión de rutas, notas y herramientas de workflow. En uso activo.',
      tags: ['App', 'iOS', 'Live'],
    },
    {
      title: 'Marca ORVEXIA',
      description: 'Identidad de empresa, logo y sistema de color. Activa y creciendo.',
      tags: ['Brand', 'Design', 'Live'],
    },
  ],
}
