import Cursor from '@/components/ui/Cursor'
import StarCanvas from '@/components/ui/StarCanvas'
import ScrollProgress from '@/components/ui/ScrollProgress'
import Navbar from '@/components/layout/Navbar'
import HeroSection from '@/components/sections/HeroSection'
import AboutSection from '@/components/sections/AboutSection'
import ProjectsSection from '@/components/sections/ProjectsSection'
import { SkillsSection, AchievementsSection } from '@/components/sections/SkillsSection'
import { IdeaLabSection, ContactSection } from '@/components/sections/IdeaLabSection'

const Divider = () => (
  <div style={{ height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,107,0,0.25), rgba(255,140,0,0.15), transparent)' }} />
)

export default function Home() {
  return (
    <>
      {/* Background layers */}
      <Cursor />
      <StarCanvas />
      <ScrollProgress />

      {/* Orbes de fuego */}
      <div className="orb orb1" />
      <div className="orb orb2" />
      <div className="orb orb3" />
      <div className="orb orb4" />
      <div className="orb orb5" />

      {/* Navigation */}
      <Navbar />

      {/* Main content */}
      <main>
        <HeroSection />
        <Divider />
        <AboutSection />
        <Divider />
        <ProjectsSection />
        <Divider />
        <SkillsSection />
        <Divider />
        <AchievementsSection />
        <Divider />
        <IdeaLabSection />
        <Divider />
        <ContactSection />
      </main>

      {/* Footer */}
      <footer style={{ borderTop: '1px solid rgba(255,107,0,0.12)', padding: '32px 0', position: 'relative', zIndex: 1 }}>
        <div style={{ maxWidth: 1160, margin: '0 auto', padding: '0 clamp(1.2rem, 4vw, 2.5rem)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ fontSize: 13, color: '#7A5C3A' }}>
            © 2024 <strong style={{ color: '#FFF8F0' }}>Ernys Napoles Favier</strong> ·{' '}
            <strong style={{ color: '#FFF8F0' }}>ORVEXIA</strong> · Houston, TX
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {['Next.js + Tailwind', 'v1.0.0'].map((b) => (
              <div key={b} style={{ background: 'rgba(255,107,0,0.07)', border: '1px solid rgba(255,107,0,0.18)', color: '#C4956A', fontSize: 11, padding: '5px 12px', borderRadius: 6, fontFamily: 'JetBrains Mono' }}>
                {b}
              </div>
            ))}
          </div>
        </div>
      </footer>
    </>
  )
}
