import type { Metadata } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'Ernys Napoles Favier — Technology Founder',
  description:
    'CDL Class A Driver turned Technology Creator. Founder of ORVEXIA. Creator of Route Manager Pro. Building real-world software from real-world experience.',
  keywords: [
    'Ernys Napoles Favier', 'ORVEXIA', 'Route Manager Pro',
    'CDL Driver', 'Technology Founder', 'Self-Taught Developer',
    'Houston TX', 'Logistics Tech', 'Transportation Software',
  ],
  openGraph: {
    title: 'Ernys Napoles Favier — Technology Founder',
    description: 'CDL Driver turned Technology Creator. Founder of ORVEXIA.',
    url: 'https://ernysnapoles.dev',
    siteName: 'Ernys Napoles Favier',
    locale: 'es_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Ernys Napoles Favier — Technology Founder',
    description: 'CDL Driver turned Technology Creator. Founder of ORVEXIA.',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className="scroll-smooth">
      <body className="bg-[#060402] text-[#FFF8F0] font-sans antialiased overflow-x-hidden">
        {children}
      </body>
    </html>
  )
}
