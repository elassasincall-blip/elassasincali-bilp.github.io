# 🔥 Ernys Napoles Favier — Portfolio

Portafolio personal premium con diseño Liquid Glass + naranja fuego.
Construido con Next.js 14, TypeScript y Tailwind CSS.

---

## 🚀 Cómo correr el proyecto en tu computadora

### Paso 1 — Instalar Node.js
Si no lo tienes, descárgalo en: https://nodejs.org
(Descarga la versión "LTS")

### Paso 2 — Abrir la carpeta del proyecto
```bash
cd ernys-portfolio
```

### Paso 3 — Instalar dependencias
```bash
npm install
```

### Paso 4 — Correr el servidor de desarrollo
```bash
npm run dev
```

### Paso 5 — Abrir en el navegador
Ve a: http://localhost:3000

---

## 📁 Estructura del proyecto

```
ernys-portfolio/
├── src/
│   ├── app/
│   │   ├── layout.tsx        ← SEO, fonts, metadata
│   │   └── page.tsx          ← Página principal
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Cursor.tsx          ← Cursor personalizado
│   │   │   ├── StarCanvas.tsx      ← Estrellas animadas
│   │   │   └── ScrollProgress.tsx  ← Barra de progreso
│   │   ├── layout/
│   │   │   └── Navbar.tsx          ← Navegación fija
│   │   └── sections/
│   │       ├── HeroSection.tsx     ← Portada principal
│   │       ├── AboutSection.tsx    ← Tu historia
│   │       ├── ProjectsSection.tsx ← Bento de proyectos
│   │       ├── SkillsSection.tsx   ← Habilidades + trofeos
│   │       └── IdeaLabSection.tsx  ← Kanban + contacto
│   ├── lib/
│   │   └── data.ts           ← ⭐ EDITA AQUÍ TU INFORMACIÓN
│   └── styles/
│       └── globals.css       ← Estilos globales + glass
├── package.json
├── tailwind.config.ts
└── next.config.ts
```

---

## ✏️ Cómo editar tu información

Todo tu contenido está en un solo archivo:
```
src/lib/data.ts
```

Ahí puedes cambiar:
- Tu nombre, email, links sociales
- Métricas del hero (proyectos, apps, etc.)
- Tu historia y timeline
- Proyectos y roadmaps
- Habilidades y porcentajes
- Certificaciones y logros
- Ideas del laboratorio

---

## 🎨 Cómo cambiar colores

Edita las variables en `src/styles/globals.css`:
```css
:root {
  --o1: #FF6B00;  /* Naranja principal */
  --o2: #FF8C00;  /* Naranja medio */
  --o3: #FFA500;  /* Naranja suave */
  --o4: #FFB347;  /* Ámbar */
  --o5: #FFD580;  /* Dorado claro */
  --red: #FF3D00; /* Rojo-naranja */
}
```

---

## 📸 Cómo agregar tu foto

1. Guarda tu foto como `public/profile.jpg`
2. En `src/components/sections/HeroSection.tsx` busca el avatar
3. Reemplaza el `<span>ENF</span>` con:
```tsx
import Image from 'next/image'
<Image src="/profile.jpg" alt="Ernys" fill style={{ objectFit: 'cover', borderRadius: '50%' }} />
```

---

## 🌐 Cuando estés listo para subir a Vercel

```bash
# 1. Crear cuenta en vercel.com (gratis)
# 2. Instalar CLI
npm i -g vercel

# 3. Deploy
vercel

# 4. Seguir las instrucciones en pantalla
```

---

## 🛠 Tecnologías usadas

- **Next.js 14** — Framework de React
- **TypeScript** — Tipado estático
- **Tailwind CSS** — Estilos utilitarios
- **Framer Motion** — Animaciones (disponible)
- **Space Grotesk** — Fuente principal
- **JetBrains Mono** — Fuente de código

---

Hecho con 🔥 por Ernys Napoles Favier | ORVEXIA
